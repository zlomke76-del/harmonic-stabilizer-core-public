TIM PROJECT — DE BOUNDARY
T4 v1.1 EXACT FROZEN ZIP — TRANSPORT ENVELOPE

The controlling frozen ZIP is the inner file:
TIM_T4_v1_1_FROZEN_PACKET_SET_EXACT_b6f99afc_2026-08-17.zip

Required SHA-256:
b6f99afcc1f8ebdd7825441cf6228f037a3d62e4403946ad4b313d9880569917

The TAR is transport-only. Its own byte identity is not controlling.
After extraction, verify the SHA-256 of the inner ZIP before execution.
Do not execute any T4 packet unless the inner ZIP hash matches exactly.
